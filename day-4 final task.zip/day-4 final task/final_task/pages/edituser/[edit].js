import React, { useEffect, useState } from 'react';
import style from '@/styles/AddUser.module.css';
import axios from 'axios';
import Head from 'next/head';
import Header from '../components/Header';
import { useRouter } from 'next/router';
import { Button } from 'bootstrap';

export default function edituser() {
    const [userData, setUserData] = useState();
    // const [userData1, setUserData1] = useState();
    const [hobby, setHobby] = useState();
    const router = useRouter();
    const handlechange = () => {
        const hobby2 = [];
        const hobby1 = document.getElementsByName("hobby");
        if (hobby1) {
            for (let i = 0; i < hobby1.length; i++) {
                if (hobby1[i].checked) {
                    hobby2.push(hobby1[i].value);
                }
            }
            setHobby(hobby2);
        }
    }
    const handledatachange = (e) => {
        setUserData({ ...userData, [e.target.name]: e.target.value })
    }
    const handlesubmit = async (e) => {
        e.preventDefault();
        if (e.target.code.value == "" || (/^[ ]*$/.test(e.target.code.value))) {
            alert("enter code properly");
        }
        else if (e.target.firstname.value == "" || !(/^[0-9a-zA-Z]*$/.test(e.target.firstname.value))) {
            alert("enter first name properly");
        }
        else if (e.target.lastname.value == "" || !(/^[0-9a-zA-Z]*$/.test(e.target.lastname.value))) {
            alert("Enter Last Name Properly");
        }
        else if (e.target.email.value == "" || !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(e.target.email.value))) {
            alert("please enter email in proper formate");
        }
        else if (e.target.gender.value == "") {
            alert("please select your gender");
        }
        else if (e.target.country.value == "Choose Your Country...") {
            alert("please select your country");
        }
        else if (hobby == "" || hobby == "indefined") {
            alert("please select atleast one hobby");
        }
        else {
            // const data = new FormData(e.target);
            const resp = await axios.post('/api/editUser', { id: router.query.edit, user: userData, Hobby: hobby });
            if (resp.data == "user Edited") {
                alert(resp.data);
                router.push('/HomePage');
            }
            else {
                alert(resp.data);
            }
        }
    }
    const defaultfunction = async () => {
        const res = await axios.post('/api/Getuser', { ID: router.query.edit });
        setUserData(res.data[0]);
        setHobby(res.data[0].hobby);
    }
    const EditProfile = (e) => {
        e.preventDefault();
        document.getElementById('upload').style.visibility = "visible";
    }
    const handleeditprofile = async (e) => {
        e.preventDefault();
        const data = new FormData(e.target);
    
        const res = await axios.post('/api/edit_profile/', data,{headers : {
            'code':userData.code,
            'img': userData.filename
        }});
        if(res.data == "profile updated"){
            alert("profile updated");
        }
        else{
            alert(res.data);
        }
        document.getElementById("upload").style.visibility = "hidden";
        defaultfunction();
    }
    useEffect(() => {
        defaultfunction();
    }, [])
    return (
        <div>
            <Head>
                <title>Add User</title>
            </Head>
            <div>
                <Header />
            </div>
            {userData &&
                <div className={style.AddUser}>
                    <form onSubmit={handleeditprofile}>
                        <div className='d-flex justify-content-center' >

                            <div>
                                <img src={'/images/' + userData.filename} style={{ height: "30vh", width: "30vh", borderRadius: "30vh" }}></img>
                                <button onClick={(e) => { EditProfile(e) }} className='btn btn-primary btn-sm align-top'>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                        <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z" />
                                    </svg>
                                </button>
                            </div>
                        
                            <div className="form-group col-md-2 m-1" style={{visibility: "hidden"}} id="upload">
                                <label for="img"> Upload Photo</label>
                                <input type="file" className='form-control' id="img" name="img" />
                                <button type="submit" className='btn btn-success text-right'>update</button>
                            </div>
                        </div>
                    </form>
                    <form onSubmit={handlesubmit}>
                        {/* code */}

                        <div className="form-row d-flex justify-content-center">
                            <div className="form-group col-md-8">
                                <label for="code">code</label>
                                <input type="text" className="form-control" disabled defaultValue={userData.code} onChange={handledatachange} id="code" name="code" placeholder="code should be unique" />
                            </div>
                        </div>

                        {/* firstname lastname */}
                        <div className="form-row d-flex justify-content-center">
                            <div className="form-group col-md-4 m-1 ">
                                <label for="firstname">First Name</label>
                                <input type="text" className="form-control" defaultValue={userData.firstname} onChange={handledatachange} id="firstname" name="firstname" placeholder="Enter First Name" />
                            </div>
                            <div className="form-group col-md-4 m-1 ">
                                <label for="lastname">Last Name</label>
                                <input type="text" className="form-control" defaultValue={userData.lastname} onChange={handledatachange} id="lastname" name="lastname" placeholder="Enter Last Name" />
                            </div>
                        </div>
                        {/* email gender */}
                        <div className="form-row d-flex justify-content-center">
                            <div className="form-group col-md-4 m-1">
                                <label for="email">Email</label>
                                <input type="text" className="form-control" defaultValue={userData.email} onChange={handledatachange} name="email" id="email" placeholder="Enter Email Here" />
                            </div>
                            <div className="form-group col-md-4 m-1">
                                <label for="Gender">Gender</label>
                                <div className='form-control'>
                                    <input type="radio" id="male" defaultChecked={userData.gender == "M"} onChange={handledatachange} className='m-1' name="gender" value="M" />Male
                                    <input type="radio" id="female" defaultChecked={userData.gender == "F"} onChange={handledatachange} className='m-1' name="gender" value="F" />Female
                                </div>
                            </div>
                        </div>
                        {/* country upload photo */}
                        <div className="form-row d-flex justify-content-center">
                            <div className="form-group col-md-8 m-1">
                                <label for="country">Country</label>
                                <select id="country" defaultValue={userData.country} onChange={handledatachange} name="country" className="form-control">
                                    <option  >Choose Your Country...</option>
                                    <option name="country" value="India" >India</option>
                                    <option name="country" value="USA">USA</option>
                                    <option name="country" value="China" >China</option>
                                    <option name="country" value="South Africa" >South Africa</option>
                                    <option name="country" value="Africa" >Africa</option>
                                    <option name="country" value="Canada" >Canada</option>
                                </select>
                            </div>

                        </div>
                        {/* hobbies */}
                        <div className="form-row d-flex justify-content-center">
                            <div className="form-group col-md-8">
                                <label for="hobbies">Hobbies</label>
                                <div className='form-control'>
                                    <input type="checkbox" defaultChecked={userData.hobby.includes("Reading")} onChange={handlechange} className='m-2' name="hobby" id="Reading" value="Reading" />Reading
                                    <input type="checkbox" defaultChecked={userData.hobby.includes("Travelling")} onChange={handlechange} className='m-2' name="hobby" id="Travelling" value="Travelling" />Travelling
                                    <input type="checkbox" defaultChecked={userData.hobby.includes("Music")} onChange={handlechange} className='m-2' name="hobby" id="Music" value="Music" />Music
                                    <input type="checkbox" defaultChecked={userData.hobby.includes("Cricket")} onChange={handlechange} className='m-2' name="hobby" id="Cricket" value="Cricket" />Cricket
                                    <input type="checkbox" defaultChecked={userData.hobby.includes("Dancing")} onChange={handlechange} className='m-2' name="hobby" id="Dancing" value="Dancing" />Dancing
                                    <input type="checkbox" defaultChecked={userData.hobby.includes("Singing")} onChange={handlechange} className='m-2' name="hobby" id="Singing" value="Singing" />Singing
                                </div>
                            </div>
                        </div>
                        <div className="form-row d-flex justify-content-center">
                            <button type="submit" className="btn btn-primary m-4" >
                                <svg className="m-2" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-add" viewBox="0 0 16 16">
                                    <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
                                    <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z" />
                                </svg> Add User
                            </button>
                        </div>
                    </form>
                </div>
            }
        </div>
    )
}
