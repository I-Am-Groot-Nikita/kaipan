import con from "../connection/Connection";

export default function Getuser(req,res){
    console.log(req.body.ID);

    // con.query(`select * from User_Management_35 where id = ${req.body.ID} ;`, (err, result) => {
    con.query(`select id, code,firstname,lastname, email, gender, hobby, filename, country, state, date_format(dateadded,"%d/%m/%Y %h:%i:%s") as dateadded,date_format(dateupdated,"%d/%m/%Y %h:%i:%s") as dateupdated, endeffdt, active from User_Management_35 where id = ${req.body.ID} ;`, (err, result) => {
        if (err) throw err;
        res.send(result);
    })
}