import con from "../connection/Connection";
import formidable from "formidable";
let mv = require("mv");

export const config = {
    api: {
        bodyParser: false,
    },
};

export default async function AddUser(req, res) {

    const form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {

        con.query(`select code from User_Management_35;`,(err,result)=>{
            if(err) throw err;
            let count = 0;
            for(let i = 0 ; i < result.length ; i++){
                if(result[i].code == fields.code){
                    res.send("code is already taken please select another code");
                    break;
                }
                else{
                    count++
                }
            }
            if(count == result.length){
                if(files.img.originalFilename == ''){
                    res.send("insert image for your profile");
                }
                else{
                    var oldPath = files.img.filepath;  
                    var newPath = `./public/Images/${files.img.originalFilename}`;
                    mv(oldPath, newPath, function (err) { });
                    con.query(`insert into User_Management_35 (id, code, firstname, lastname, email, gender, hobby, filename, country, state, dateadded, dateupdated, endeffdt, active) values ("","${fields.code}","${fields.firstname}","${fields.lastname}","${fields.email}","${fields.gender}","${req.headers['hobby']}","${files.img.originalFilename}","${fields.country}","N",concat(curdate()," ",curtime()),"","","yes");`, (err, result) => {
                        if (err) throw err;
                        res.send("data added");
                    })
                }
            }
        })
    });
}
