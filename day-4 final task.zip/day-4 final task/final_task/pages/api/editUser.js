import con from "../connection/Connection";
export default async function AddUser(req, res) {
    con.query(`update User_Management_35 set firstname = "${req.body.user.firstname}", lastname = "${req.body.user.lastname}",  email ="${req.body.user.email}", gender= "${req.body.user.gender}", hobby = "${req.body.Hobby}", country="${req.body.user.country}", dateupdated = concat(curdate()," ",curtime()) where id =${req.body.id};`, (err, result) => {
        if (err) throw err;
        res.send("user Edited");
    })
}   