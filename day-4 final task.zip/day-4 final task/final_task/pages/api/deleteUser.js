import con from "../connection/Connection";

export default function deleteUser(req, res){
    con.query(`update User_Management_35 set active = "no",endeffdt = concat(curdate()," ",curtime()) where id = ${req.body.Id};`, (err, result) => {
        if (err) throw err;
        res.send("deleted");
    })
}