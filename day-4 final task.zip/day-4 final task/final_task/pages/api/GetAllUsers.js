import con from "../connection/Connection";

export default async function GetAllUsers(req,res){
    con.query(`select id, code, concat(firstname," ",lastname) as name, email, gender, hobby, filename, country, state, dateadded, dateupdated, endeffdt, active from User_Management_35 where active = "yes";`,(err,result)=>{
        if(err) throw err;
        res.send(result);
    })
}