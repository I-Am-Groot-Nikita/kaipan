import con from "../connection/Connection";

export default async function GetAllUsers(req,res){
    // console.log(req.body);
    if (req.body.State == "N") {
        con.query(`update User_Management_35 set state = "Y"  where id = ${req.body.Id}`, (err, result) => {
            if (err) throw err;
            res.send("OKAY");
        })
    }
    else {
        con.query(`update User_Management_35 set state = "N" where id = ${req.body.Id}`, (err, result) => {
            if (err) throw err;
            res.send("OKAY");
        })
    }
}