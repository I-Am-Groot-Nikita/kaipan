import con from "../connection/Connection";
import formidable from "formidable";
let mv = require("mv");

export const config = {
    api: {
        bodyParser: false,
    },
};

export default async function AddUser(req, res) {

    const form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {


        if (files.img.originalFilename == '') {
            res.send("insert image for your profile");
        }
        else {
            if (files.img.originalFilename == "" || files.img.originalFilename == 'undefined') {
                res.send("insert image properly..");
            }
            else if (files.img.originalFilename == req.headers['img']) {
                res.send("same image is selected...");
            }
            else {
                var oldPath = files.img.filepath;
                var newPath = `./public/Images/${files.img.originalFilename}`;
                mv(oldPath, newPath, function (err) { });
                con.query(`update User_Management_35 set filename="${files.img.originalFilename}" where code ="${req.headers['code']}";`, (err, result) => {
                    if (err) throw err;
                    res.send("profile updated");
                })
            }
        }

    })

}