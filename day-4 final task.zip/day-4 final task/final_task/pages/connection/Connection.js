import mysql from 'mysql';

var con = mysql.createConnection({
    host: "192.168.2.8",
    user: "trainee",
    password: "trainee@123",
    database: "traineedb"
  });
  export default con;