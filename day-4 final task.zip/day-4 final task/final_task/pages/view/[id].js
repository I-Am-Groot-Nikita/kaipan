import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/router';
import axios from 'axios';
import style from '@/styles/View.module.css'
import Header from '../components/Header';
import Head from 'next/head';

export default function View() {

	// Calling useRouter() hook
	const [userData, setUserData] = useState();
	const router = useRouter()
	const defaultFunction = async () => {
		const res = await axios.post('/api/Getuser',{ID : router.query.id})
		setUserData(res.data[0]);
	}
	useEffect(() => {
		defaultFunction();
	}, []);

	// console.log(router.query.id)
	return (
		<div>
			 <Head>
                <title>View User Info</title>
            </Head>
			<div>
				<Header />
			</div>
			<div className='d-flex justify-content-center m-5'>

			
			<div className={style.ViewUser}>

				{userData &&(
					<>
					<div>
						<img src={"/Images/"+ userData.filename}></img>
					</div>
					<div>
				<table>
					<tr>
						<td className={style.td1}>Code</td>
						<td> : </td>
						<td className={style.td3}>{userData.code}</td>
					</tr>
					<tr>
						<td className={style.td1}>First Name</td>
						<td> : </td>
						<td className={style.td3}>{userData.firstname}</td>
					</tr>
					<tr>
						<td className={style.td1}>Last Name</td>
						<td> : </td>
						<td className={style.td3}>{userData.lastname}</td>
					</tr>
					<tr>
						<td className={style.td1}>Email</td>
						<td> : </td>
						<td className={style.td3}>{userData.email}</td>
					</tr>
					<tr>
						<td className={style.td1}>Gender</td>
						<td> : </td>
						<td className={style.td3}>{userData.gender}</td>
					</tr>
					<tr>
						<td className={style.td1}>Hobbies</td>
						<td> : </td>
						<td className={style.td3}>{userData.hobby}</td>
					</tr>
					<tr>
						<td className={style.td1}>Country</td>
						<td> : </td>
						<td className={style.td3}>{userData.country}</td>
					</tr>
					<tr>
						<td className={style.td1}>status</td>
						<td> : </td>
						{userData.state == "Y" ? <td className={style.td3}>Active</td> : <td className={style.td3}>Inactive</td>}
					</tr>	
					<tr>
						<td className={style.td1}>Joining date</td>
						<td> : </td>
						<td className={style.td3}>{userData.dateadded}</td>
					</tr>
					<tr>
						<td className={style.td1}>Last update</td>
						<td> : </td>
						<td className={style.td3}>{userData.dateupdated}</td>
					</tr>
				</table>
				</div>
				</>
				)}
			</div>
			</div>
		</div>
	)
}

