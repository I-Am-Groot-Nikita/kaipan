import React, { useState ,useEffect} from 'react'
import Header from './components/Header'
import style from '@/styles/AddUser.module.css' 
import axios from 'axios'
import { useRouter } from 'next/router'
import Head from 'next/head'

export default function AddUser() {
    const [hobby,setHobby] = useState();
    const router = useRouter();
    const handlechange = () =>{
        const hobby2 = [];
        const hobby1 = document.getElementsByName("hobby");
        if(hobby1){     
            for(let i = 0 ; i < hobby1.length ; i++){
                if(hobby1[i].checked){
                    hobby2.push(hobby1[i].value);
                }
            }
            setHobby(hobby2);
        }
    }
    const handleSubmit = async (e) => {
        e.preventDefault();
        if(e.target.code.value == "" || (/^[ ]*$/.test(e.target.code.value))){
            alert("enter code properly");
        }
        else if (e.target.firstname.value == "" || !(/^[0-9a-zA-Z]*$/.test(e.target.firstname.value))){
            alert("enter first name properly");
        }
        else if (e.target.lastname.value == "" || !(/^[0-9a-zA-Z]*$/.test(e.target.lastname.value))) {
            alert("Enter Last Name Properly");
        }
        else if (e.target.email.value == "" || !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(e.target.email.value))) {
            alert("please enter email in proper formate");
        }
        else if (e.target.gender.value == "") {
            alert("please select your gender");
        }
        else if (e.target.country.value == "Choose Your Country...") {
            alert("please select your country");
        }
        else if (hobby == "" || hobby == "indefined" ) {
            alert("please select atleast one hobby");
        }
        else {     
            const data = new FormData(e.target);
            const resp = await axios.post('/api/AddUser',data,{
                headers: {
                  'Hobby': `${hobby}` 
                }
              });
              if(resp.data == "data added"){
                  alert(resp.data);
                  router.push('./HomePage');
                }
                else{
                alert(resp.data);
            }
        }
    }

    return (
        <div>
            <Head>
                <title>Add User</title>
            </Head>
            <div>
                <Header />
            </div>

            <div className={style.AddUser}>
                <form onSubmit={handleSubmit}>
                    {/* code */}
                    <div className="form-row d-flex justify-content-center">
                        <div className="form-group col-md-8">
                            <label for="code">code</label>
                            <input type="text" className="form-control" id="code" name="code" placeholder="code should be unique" />
                        </div>
                    </div>
                    {/* firstname lastname */}
                    <div className="form-row d-flex justify-content-center">
                        <div className="form-group col-md-4 m-1 ">
                            <label for="firstname">First Name</label>
                            <input type="text" className="form-control" id="firstname" name="firstname" placeholder="Enter First Name" />
                        </div>
                        <div className="form-group col-md-4 m-1 ">
                            <label for="lastname">Last Name</label>
                            <input type="text" className="form-control" id="lastname" name="lastname" placeholder="Enter Last Name" />
                        </div>
                    </div>
                    {/* email gender */}
                    <div className="form-row d-flex justify-content-center">
                        <div className="form-group col-md-4 m-1">
                            <label for="email">Email</label>
                            <input type="text" className="form-control" name="email" id="email" placeholder="Enter Email Here" />
                        </div>
                        <div className="form-group col-md-4 m-1">
                            <label for="Gender">Gender</label>
                            <div className='form-control'>
                                <input type="radio" id="male" className='m-1' name="gender" value="M" />Male
                                <input type="radio" id="female" className='m-1' name="gender" value="F" />Female
                            </div>
                        </div>
                    </div>
                    {/* country upload photo */}
                    <div className="form-row d-flex justify-content-center">
                        <div className="form-group col-md-4 m-1">
                            <label for="country">Country</label>
                            <select id="country" name="country" className="form-control">
                                <option defaultChecked >Choose Your Country...</option>
                                <option name="country" value="India" >India</option>
                                <option name="country" value="USA">USA</option>
                                <option name="country" value="China" >China</option>
                                <option name="country" value="South Africa" >South Africa</option>
                                <option name="country" value="Africa" >Africa</option>
                                <option name="country" value="Canada" >Canada</option>
                            </select>
                        </div>
                        <div className="form-group col-md-4 m-1">
                            <label for="img"> Upload Photo</label>
                            <input type="file" className='form-control' id="img" name="img" />
                        </div>
                    </div>
                    {/* hobbies */}
                    <div className="form-row d-flex justify-content-center">
                        <div className="form-group col-md-8">
                            <label for="hobbies">Hobbies</label>
                            <div className='form-control'>
                                <input type="checkbox" onChange={handlechange}className='m-2' name="hobby" id="Reading" value="Reading" />Reading
                                <input type="checkbox" onChange={handlechange}className='m-2' name="hobby" id="Travelling" value="Travelling" />Travelling
                                <input type="checkbox" onChange={handlechange}className='m-2' name="hobby" id="Music" value="Music" />Music
                                <input type="checkbox" onChange={handlechange}className='m-2' name="hobby" id="Cricket" value="Cricket" />Cricket
                                <input type="checkbox" onChange={handlechange}className='m-2' name="hobby" id="Dancing" value="Dancing" />Dancing
                                <input type="checkbox" onChange={handlechange}className='m-2' name="hobby" id="Singing" value="Singing" />Singing
                            </div>
                        </div>
                    </div>
                    <div className="form-row d-flex justify-content-center">
                        <button type="submit" className="btn btn-primary m-4" >
                        <svg className="m-2" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-add" viewBox="0 0 16 16">
                                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
                                <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z" />
                            </svg> Add User
                            </button>
                    </div>
                </form>
            </div>
        </div>
    )
}
