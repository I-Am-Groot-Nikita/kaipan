"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/GetAllUsers";
exports.ids = ["pages/api/GetAllUsers"];
exports.modules = {

/***/ "mysql":
/*!************************!*\
  !*** external "mysql" ***!
  \************************/
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ "(api)/./pages/api/GetAllUsers.js":
/*!**********************************!*\
  !*** ./pages/api/GetAllUsers.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ GetAllUsers)\n/* harmony export */ });\n/* harmony import */ var _connection_Connection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../connection/Connection */ \"(api)/./pages/connection/Connection.js\");\n\nasync function GetAllUsers(req, res) {\n    _connection_Connection__WEBPACK_IMPORTED_MODULE_0__[\"default\"].query(`select id, code, concat(firstname,\" \",lastname) as name, email, gender, hobby, filename, country, state, dateadded, dateupdated, endeffdt, active from User_Management_35 where active = \"yes\";`, (err, result)=>{\n        if (err) throw err;\n        res.send(result);\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvR2V0QWxsVXNlcnMuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBMkM7QUFFNUIsZUFBZUMsWUFBWUMsR0FBRyxFQUFDQyxHQUFHLEVBQUM7SUFDOUNILG9FQUFTLENBQUMsQ0FBQywrTEFBK0wsQ0FBQyxFQUFDLENBQUNLLEtBQUlDLFNBQVM7UUFDdE4sSUFBR0QsS0FBSyxNQUFNQSxJQUFJO1FBQ2xCRixJQUFJSSxJQUFJLENBQUNEO0lBQ2I7QUFDSixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZmluYWxfdGFzay8uL3BhZ2VzL2FwaS9HZXRBbGxVc2Vycy5qcz85ODVmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjb24gZnJvbSBcIi4uL2Nvbm5lY3Rpb24vQ29ubmVjdGlvblwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gR2V0QWxsVXNlcnMocmVxLHJlcyl7XHJcbiAgICBjb24ucXVlcnkoYHNlbGVjdCBpZCwgY29kZSwgY29uY2F0KGZpcnN0bmFtZSxcIiBcIixsYXN0bmFtZSkgYXMgbmFtZSwgZW1haWwsIGdlbmRlciwgaG9iYnksIGZpbGVuYW1lLCBjb3VudHJ5LCBzdGF0ZSwgZGF0ZWFkZGVkLCBkYXRldXBkYXRlZCwgZW5kZWZmZHQsIGFjdGl2ZSBmcm9tIFVzZXJfTWFuYWdlbWVudF8zNSB3aGVyZSBhY3RpdmUgPSBcInllc1wiO2AsKGVycixyZXN1bHQpPT57XHJcbiAgICAgICAgaWYoZXJyKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgcmVzLnNlbmQocmVzdWx0KTtcclxuICAgIH0pXHJcbn0iXSwibmFtZXMiOlsiY29uIiwiR2V0QWxsVXNlcnMiLCJyZXEiLCJyZXMiLCJxdWVyeSIsImVyciIsInJlc3VsdCIsInNlbmQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/GetAllUsers.js\n");

/***/ }),

/***/ "(api)/./pages/connection/Connection.js":
/*!****************************************!*\
  !*** ./pages/connection/Connection.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql */ \"mysql\");\n/* harmony import */ var mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql__WEBPACK_IMPORTED_MODULE_0__);\n\nvar con = mysql__WEBPACK_IMPORTED_MODULE_0___default().createConnection({\n    host: \"192.168.2.8\",\n    user: \"trainee\",\n    password: \"trainee@123\",\n    database: \"traineedb\"\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (con);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9jb25uZWN0aW9uL0Nvbm5lY3Rpb24uanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQTBCO0FBRTFCLElBQUlDLE1BQU1ELDZEQUFzQixDQUFDO0lBQzdCRyxNQUFNO0lBQ05DLE1BQU07SUFDTkMsVUFBVTtJQUNWQyxVQUFVO0FBQ1o7QUFDQSxpRUFBZUwsR0FBR0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2ZpbmFsX3Rhc2svLi9wYWdlcy9jb25uZWN0aW9uL0Nvbm5lY3Rpb24uanM/ZDc1MiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnO1xyXG5cclxudmFyIGNvbiA9IG15c3FsLmNyZWF0ZUNvbm5lY3Rpb24oe1xyXG4gICAgaG9zdDogXCIxOTIuMTY4LjIuOFwiLFxyXG4gICAgdXNlcjogXCJ0cmFpbmVlXCIsXHJcbiAgICBwYXNzd29yZDogXCJ0cmFpbmVlQDEyM1wiLFxyXG4gICAgZGF0YWJhc2U6IFwidHJhaW5lZWRiXCJcclxuICB9KTtcclxuICBleHBvcnQgZGVmYXVsdCBjb247Il0sIm5hbWVzIjpbIm15c3FsIiwiY29uIiwiY3JlYXRlQ29ubmVjdGlvbiIsImhvc3QiLCJ1c2VyIiwicGFzc3dvcmQiLCJkYXRhYmFzZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/connection/Connection.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/GetAllUsers.js"));
module.exports = __webpack_exports__;

})();